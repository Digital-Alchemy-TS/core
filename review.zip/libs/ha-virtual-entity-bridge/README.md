# home-assistant

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build home-assistant` to build the library.

## Running unit tests

Run `nx test home-assistant` to execute the unit tests via [Jest](https://jestjs.io).
