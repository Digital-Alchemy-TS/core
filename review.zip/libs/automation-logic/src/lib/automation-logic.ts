export function automationLogic(): string {
  return "automation-logic";
}
