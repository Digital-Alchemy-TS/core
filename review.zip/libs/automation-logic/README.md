# automation-logic

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build automation-logic` to build the library.

## Running unit tests

Run `nx test automation-logic` to execute the unit tests via [Jest](https://jestjs.io).
