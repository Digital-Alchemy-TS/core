# gotify

This library was generated with [Nx](https://nx.dev).

## Building

Run `nx build gotify` to build the library.

## Running unit tests

Run `nx test gotify` to execute the unit tests via [Jest](https://jestjs.io).
