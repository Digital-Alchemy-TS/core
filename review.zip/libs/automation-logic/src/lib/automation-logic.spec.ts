import { automationLogic } from "./automation-logic";

describe("automationLogic", () => {
  it("should work", () => {
    expect(automationLogic()).toEqual("automation-logic");
  });
});
